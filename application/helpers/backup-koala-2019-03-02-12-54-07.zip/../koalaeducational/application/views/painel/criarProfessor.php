<div class="mg-b-15">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="bg-site">
          <!-- C O N T E U D O -->


            <div class="card" >
              <div class="card-header" id="dash-professor-card-title">
                <h4>Adicionar um professor</h4>
              </div>
              <br><br><div class="card-body">
                <div class="row">
                  <div class="col-lg-4 col-lg-offset-2">

                    <a href="<?php echo base_url('adms/criarProfessor/new');?>" class="choice-teacher new"><i style="font-size: 3em;"class="educate-icon educate-professor"></i><br>Novo usuário</a>
                  </div>
                  <div class="col-lg-4">
                    
                    <a href="<?php echo base_url('adms/criarProfessor/search');?>" class="choice-teacher sea"><i style="font-size: 3em;"class="educate-icon educate-search"></i><br>Usuário existente</a>
                  </div>
                </div>
              </div>
            </div>



          <!-- FIM CONTEUDO -->
        </div>
      </div>
    </div>
  </div>
