
<div class="mg-b-15">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-offset-1 col-md-offset-1 col-lg-10 col-md-10 col-sm-12 col-xs-12">
        <div class="bg-site">
          <!-- C O N T E U D O -->
          <div class="card" >
            <div class="card-header mg-b-30" id="dash-professor-card-title">
              
            </div>

            <div class="card-body">
             
              <div class="row mg-b-30">
                <div class="col-lg-10 col-lg-offset-1 ">
                  <div class="titulo-pergunta" >
                    Em construção
                    </div>
                 
                </div>
              </div>
              
            </div>
          </div>
        <!-- FIM CONTEUDO -->
      </div>
    </div>
  </div>
</div>
