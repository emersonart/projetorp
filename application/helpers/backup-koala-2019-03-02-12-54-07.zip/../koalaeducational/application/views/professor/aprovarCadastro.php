<div class="sedules-area mg-b-30">
            <div class="container-fluid">
                <div class="row mg-b-15">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="analysis-progrebar">
                            <div class="analysis-progrebar-content">
                                <li style="list-style-type:none">Tiago Dos Santos Coutinho <a class="pull-right label-info label-4 label"><i class="fa fa-thumbs-down fa-2x"></i></a> <a class="pull-right label-danger label-1 label" style="margin-right: 10px;"><i class="fa fa-thumbs-up fa-2x"></i></a></li>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="analysis-progrebar reso-mg-b-30 res-mg-t-30 table-mg-t-pro-n">
                            <div class="analysis-progrebar-content">
                                <div class="analysis-progrebar-content">
                                <li style="list-style-type:none">Tiago Dos Santos Coutinho <a class="pull-right label-info label-4 label"><i class="fa fa-thumbs-down fa-2x"></i></a> <a class="pull-right label-danger label-1 label" style="margin-right: 10px;"><i class="fa fa-thumbs-up fa-2x"></i></a></li>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="analysis-progrebar reso-mg-b-30 res-tablet-mg-t-30 dk-res-t-pro-30">
                            <div class="analysis-progrebar-content">
                                <div class="analysis-progrebar-content">
                                <li style="list-style-type:none">Tiago Dos Santos Coutinho <a class="pull-right label-info label-4 label"><i class="fa fa-thumbs-down fa-2x"></i></a> <a class="pull-right label-danger label-1 label" style="margin-right: 10px;"><i class="fa fa-thumbs-up fa-2x"></i></a></li>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <div class="analysis-progrebar res-tablet-mg-t-30 dk-res-t-pro-30">
                            <div class="analysis-progrebar-content">
                                <div class="analysis-progrebar-content">
                                <li style="list-style-type:none">Tiago Dos Santos Coutinho <a class="pull-right label-info label-4 label"><i class="fa fa-thumbs-down fa-2x"></i></a> <a class="pull-right label-danger label-1 label" style="margin-right: 10px;"><i class="fa fa-thumbs-up fa-2x"></i></a></li>
                            </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<div class="mg-b-15">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="bg-site">
          <!-- C O N T E U D O -->


            



          <!-- FIM CONTEUDO -->
        </div>
      </div>
    </div>
  </div>
